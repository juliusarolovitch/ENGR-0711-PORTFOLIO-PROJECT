%Team 16: Erfan, Julius, and Will 
function sequence_sum = squences(choice, array)

%sorting array for scoring
for i = 1:length(array)
    for j = 1:length(array)-1
        if (array(j) > array(j+1))
            temp1 = array(j);
            temp2 = array(j+1);
            array(j) = temp2;
            array(j+1) = temp1;
        end
    end
end

switch choice
    case 10
        %small straight scoring
        for z = 1:length(array)- 4
            if (array(z+1) == array(z) + 1 && array(z+2) == array(z)+2 && array(z+3) == array(z)+3)
                sequence_sum = 30;
            else
                sequence_sum = 0;
            end
        end


    case 11
        %large straight scoring
        for k = 1:length(array)-1
            if array(k+1) == array(k)+1
                sequence_sum = 40;
            else
                sequence_sum = 0;
            end
        end
end
