%Team 16: Erfan, Julius, and Will 

%defines variables for entire game
scores_array = zeros(1,20);
upper_total = 0;
lower_total = 0;
grand_total = 0;
count = 0;
yahtzee_counter = 0;
one_hundo = 0;

%loop that allows user to keep rolling until all categories have been
%attempted
while count < 13

    %defines variables and arrays needed for each roll
    upper_sum = 0;
    middle_sum = 0;
    sequence_sum = 0;
    chance_sum = 0;
    roll_again = 1;
    rolls = 0;
    array = ceil(6*rand(1,5));

    %rolls dice and allows user to roll up to 3 times with whichever dice
    %they pick
    while  roll_again == 1
        if (rolls == 0)
            %calls function that displays dice images
            diceImages(array);
            rolls = rolls + 1;
            roll_again = menu('Do you want to roll again?', 'yes', 'no');
        elseif (rolls <= 2)
            go_again = menu('How many dice do you want to re-roll?', '1', '2','3','4','5');
            for z = 1:go_again
                number = menu('What die number do you want to re-roll?', '1','2','3', '4','5');
                array(number) = ceil(6*rand(1));
            end
            %calls function that displays dice images
            diceImages(array);
            rolls = rolls + 1;
            if (rolls == 1 || rolls == 2)
                roll_again = menu('Do you want to roll again?', 'yes', 'no');
            else
                roll_again = 2;
            end
        end

    end
    
    pause;
    
    %branch statement for yahtzee or other scoring
    if (max(array) == min(array))
        choice = 13;
        yahtzee_counter = yahtzee_counter + 1;
        disp('Yahtzee!');

    else
        %gets user input for scoring
        choice = menu('How do you want to score your roll?', 'Ones', 'Twos', 'Threes', 'Fours', 'Fives', 'Sixes', '3 of a Kind', '4 of a kind', 'Full House', 'Small Straight', 'Large Straight', 'Chance');

        %switch case that sends user's score to appropriate scoring
        %function and adds result to total at end
        switch choice
            case {1, 2, 3, 4, 5, 6}
                upper_sum = UpperSection(choice, array);
                upper_total = upper_sum + upper_total;

            case {7, 8, 9}
                middle_sum = equalCategories(choice, array);
                lower_total = lower_total + middle_sum;

            case {10, 11}
                sequence_sum = squences(choice, array);
                lower_total = lower_total + sequence_sum;

            case 12
                chance_sum = sum(array);
                lower_total = lower_total + chance_sum;
        end
        pause;

    end
    %calls function to display scores on scorecard
    [scores_array, one_hundo, upper_total] = scorecard(choice, upper_sum, upper_total, scores_array, middle_sum, sequence_sum, chance_sum, yahtzee_counter, one_hundo);

    %adds yahtzee bonuses to total
    lower_total = one_hundo + lower_total;

    %tracks number of times user rolled
    count = count + 1;
    pause;
end

%adds bonus to upper total if conditions met
if (upper_total >= 63)
    upper_total = upper_total + 35;
    text(345, 710, '35')
end

%displays totals
text(345, 760, num2str(upper_total))
text(345, 1187, num2str(upper_total))
text(345, 1215, num2str(lower_total))

%finds and displays grand total to scorecard and command window
grand_total = lower_total + upper_total;

text(345, 1235, num2str(grand_total));
DISP(['YOUR GRAND TOTAL IS: ', num2str(grand_total)]);





