%Team 16: Erfan, Julius, and Will 
function diceImages(array)


%for loop and switch case to display the rolls and images of the dice
x = 0;
for i = 1:length(array)
    switch array(i)
        case 1
            x = x+1;
            one = imread('one.png');
            subplot(1,5,x)
            imshow(one)
            title(['Die ', num2str(x)])

        case 2
            x = x+1;
            two = imread("two.png");
            subplot(1,5,x)
            imshow(two)
            title(['Die ', num2str(x)])

        case 3
            x = x+1;
            three = imread('three.png');
            subplot(1,5,x)
            imshow(three)
            title(['Die ', num2str(x)])

        case 4
            x = x+1;
            four = imread('four.png');
            subplot(1,5,x)
            imshow(four)
            title(['Die ', num2str(x)])

        case 5
            x = x+1;
            five = imread('five.png');
            subplot(1,5,x)
            imshow(five)
            title(['Die ', num2str(x)])

        case 6
            x = x+1;
            six = imread('six.png');
            subplot(1,5,x)
            imshow(six)
            title(['Die ', num2str(x)])
    end

end