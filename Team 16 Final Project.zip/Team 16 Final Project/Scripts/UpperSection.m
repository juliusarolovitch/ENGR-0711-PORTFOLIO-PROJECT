%Team 16: Erfan, Julius, and Will
function upper_sum = UpperSection(choice, array)

%function that scores ones, twos, threes, fours, fives, and sixes
y = 0;

%adds dice that equal selected choice of scoring
for i = 1:length(array)
    if array(i) == choice
        y = y + choice;
    end
end

upper_sum = y;