%Team 16: Erfan, Julius, and Will 
function [scores_array, one_hundo, upper_total] = scorecard (choice, upper_sum, upper_total, scores_array, middle_sum, sequence_sum, chance_sum, yahtzee_counter, one_hundo)

%function displaying text on scorcard

card = imread('yahtzee.png');

%switch case assigning value to elements in scoring array
switch choice
    case 1
        scores_array(1) = upper_sum;

    case 2
        scores_array(2) = upper_sum;

    case 3
        scores_array(3) = upper_sum;

    case 4
        scores_array(4) = upper_sum;

    case 5
        scores_array(5) = upper_sum;

    case 6
        scores_array(6) = upper_sum;

    case 7
        scores_array(7) = middle_sum;

    case 8
        scores_array(8) = middle_sum;

    case 9
        scores_array(9) = middle_sum;

    case 10
        scores_array(10) = sequence_sum;

    case 11
        scores_array(11) = sequence_sum;

    case 12
        scores_array(12) = chance_sum;

    case 13
        switch yahtzee_counter
            %incorporates yahtzee bonuses into scoring
            case 1
                scores_array(13) = 50;
            case 2
                scores_array(14) = 1;
                one_hundo = one_hundo + 100;
            case 3
                scores_array(15) = 1;
                one_hundo = one_hundo + 100;
            case 4
                scores_array(16) = 1;
                one_hundo = one_hundo + 100;
        end



end

%displays scores on scorecard
figure
imshow(card)
text(345, 220, num2str(scores_array(1)))
text(345, 294, num2str(scores_array(2)))
text(345, 368, num2str(scores_array(3)))
text(345, 442, num2str(scores_array(4)))
text(345, 516, num2str(scores_array(5)))
text(345, 590, num2str(scores_array(6)))
text(345, 650, num2str(upper_total))
text(345, 845, num2str(scores_array(7)))
text(345, 884, num2str(scores_array(8)))
text(345, 923, num2str(scores_array(9)))
text(345, 967, num2str(scores_array(10)))
text(345, 1006, num2str(scores_array(11)))
text(345, 1090, num2str(scores_array(12)))
text(345, 1048, num2str(scores_array(13)))
text(310, 1128, num2str(scores_array(14)))
text(345, 1128, num2str(scores_array(15)))
text(380, 1128, num2str(scores_array(16)))
text(345, 1160, num2str(one_hundo))

