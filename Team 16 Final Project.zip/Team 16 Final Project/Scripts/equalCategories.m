%Team 16: Erfan, Julius, and Will
function middle_sum = equalCategories(choice, array) 

%fucntion that scores 3 of a kind, 4 of a kind, and full house

%sorting array for scoring
for i = 1:length(array)
    for j = 1:length(array)-1
        if array(j) > array(j+1)
            temp1 = array(j);
            temp2 = array(j+1);
            array(j) = temp2;
            array(j+1) = temp1;
        end
    end
end

x = 1;

%switch case for options needing sorting array
switch choice
    case 7
        %3 of a kind scoring
        while x < 4
            if (array(x) == array(x+1) && array(x) == array(x+2))
                middle_sum = array(x) + array(x+1) + array(x+2);

            else
                middle_sum = 0;
            end
            x = x + 1;
        end

    case 8
        %4 of a kind scoring
        while x < 3
            if array(x) == array(x+1) && array(x) == array(x+2) && array(x) == array(x+3)
                middle_sum = array(x) + array(x+1) + array(x+2) + array(x+3);
            else
                middle_sum = 0;
            end
            x = x + 1;
        end

    case 9
        %full house scoring
        if (array(1) == array(2) && array(1) == array(3) && array(4) == array(5) || array(1) == array(2) && array(3) == array(4) && array(3) == array(5))
            middle_sum = 25;
        else
            middle_sum = 0;
        end
end



